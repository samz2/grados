<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\users;
use Faker\Generator as Faker;

$factory->define(users::class, function (Faker $faker) {
    return [
        //
    ];
});
