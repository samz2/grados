<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\cargos;
use Faker\Generator as Faker;

$factory->define(cargos::class, function (Faker $faker) {
    return [
        //
    ];
});
