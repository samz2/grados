<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\escuelas;
use Faker\Generator as Faker;

$factory->define(escuelas::class, function (Faker $faker) {
    return [
        //
    ];
});
