<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\modalidad;
use Faker\Generator as Faker;

$factory->define(modalidad::class, function (Faker $faker) {
    return [
        //
    ];
});
