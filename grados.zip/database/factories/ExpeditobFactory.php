<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\expeditob;
use Faker\Generator as Faker;

$factory->define(expeditob::class, function (Faker $faker) {
    return [
        //
    ];
});
