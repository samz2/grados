<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\tramite;
use Faker\Generator as Faker;

$factory->define(tramite::class, function (Faker $faker) {
    return [
        //
    ];
});
