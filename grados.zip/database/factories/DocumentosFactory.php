<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\documentos;
use Faker\Generator as Faker;

$factory->define(documentos::class, function (Faker $faker) {
    return [
        //
    ];
});
