<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\decano;
use Faker\Generator as Faker;

$factory->define(decano::class, function (Faker $faker) {
    return [
        //
    ];
});
