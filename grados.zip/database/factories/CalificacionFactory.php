<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\calificacion;
use Faker\Generator as Faker;

$factory->define(calificacion::class, function (Faker $faker) {
    return [
        //
    ];
});