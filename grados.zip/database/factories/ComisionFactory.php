<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\comision;
use Faker\Generator as Faker;

$factory->define(comision::class, function (Faker $faker) {
    return [
        //
    ];
});
