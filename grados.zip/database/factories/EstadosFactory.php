<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\estados;
use Faker\Generator as Faker;

$factory->define(estados::class, function (Faker $faker) {
    return [
        //
    ];
});
