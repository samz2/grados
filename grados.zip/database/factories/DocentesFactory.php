<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\docentes;
use Faker\Generator as Faker;

$factory->define(docentes::class, function (Faker $faker) {
    return [
        //
    ];
});
