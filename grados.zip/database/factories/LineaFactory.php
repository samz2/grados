<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\linea;

$factory->define(linea::class, function (Faker $faker) {
    return [
        //
    ];
});
