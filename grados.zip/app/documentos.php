<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class documentos extends Model
{
    public $table = "documentos";
    public $timestamps = false;
}
