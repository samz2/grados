<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class escuelas extends Model
{
    public $table = "escuela";
    public $timestamps = false;
}
