<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class calificacion extends Model
{
    public $table       = "calificacion";
    public $timestamps  = false;
}
