<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class expeditob extends Model
{
    public $table   = "expedito";
    public $timestamps = false;
}
