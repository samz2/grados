<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cargos extends Model
{
    public $table = "cargos";
    public $timestamps = false;
}
