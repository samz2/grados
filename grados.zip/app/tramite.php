<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tramite extends Model
{
    public $table   = "tramite";
    public $timestamps = false;
}
