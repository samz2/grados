<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class egresado extends Model
{
    public $table = "egresado";
    public $timestamps = false;
}
