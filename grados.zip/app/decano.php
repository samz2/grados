<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class decano extends Model
{
    public $table = "decano";
    public $timestamps = false;
}
