<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class titulacion extends Model
{
    public $table = "titulacion";
    public $timestamps = false;
}
