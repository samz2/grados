<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class comision extends Model
{
    public $table = "comision";
    public $timestamps = false;
}
