<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class modalidad extends Model
{
    public $table       = "modalidad";
    public $timestamps  = false;
}
