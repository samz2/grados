<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class historialproyecto extends Model
{
    public $table   = "historial";
    public $timestamps = false;
}
