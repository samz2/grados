<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class proyecto extends Model
{
    public $table       = "proyecto_tesis";
    public $timestamps  = false;
}
