<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sesion extends Model
{
    public $table = "sesion";
    public $timestamps = false;
}
