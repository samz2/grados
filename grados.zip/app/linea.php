<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class linea extends Model
{
    public $table       = "linea";
    public $timestamps  = false;
}
